<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_controller extends CI_Controller {

	function render_page($content, $data = NULL)
	{
		
	}

}

/* End of file MY_controller.php */
/* Location: ./application/core/MY_controller.php */
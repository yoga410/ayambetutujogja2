<footer class="container-fluid text-center">
				<div class="col-xs-12 col-md-3">
                    <div class="widget w-footer widget_black_studio_tinymce">
                        <h3 class="widget-title"><span class="light">Informasi</span></h3>
                        <div class="textwidget">
						Alamat : Jl. Damai Gg. Watu Gede No. 2 (Utara Hotel HYATT) Ngaglik, Sleman, Yogyakarta.</br></br>
						Parkir Luas dan Nyaman serta Live Musik dan Free Karaoke.
                        </div>
                    </div>
                </div>
				
				<div class="col-xs-12 col-md-3">
                    <div class="widget w-footer widget_black_studio_tinymce">
                        <h3 class="widget-title"><span class="light">Menerima Pesanan</span> :</h3>
                        <div class="textwidget">
						Nasi Box, Prasmanan, Ulang Tahun</br>
						Rapat, Wedding, Arisan
                        </div>
                    </div>
                </div>
				
				<div class="col-xs-12 col-md-3">
                    <div class="widget w-footer widget_black_studio_tinymce">
                        <h3 class="widget-title"><span class="light">Costumer Service</span></h3>
                        <div class="textwidget">
						<li>02744463586</li>  
						<li>08122634808</li> 
						<li>087739529280 (Whatsapp)</li> 
                        </div>
                    </div>
                </div>
				
				<div class="col-xs-12 col-md-3">
                    <div class="widget w-footer widget_black_studio_tinymce">
                        <h3 class="widget-title"><span class="light">Follow Us</span></h3>
                        <div class="social">
						<li> <a href="#"> <i class=" fa fa-facebook"> facebook  </i> </a> </li>
						<li> <a href="#"> <i class="fa fa-twitter">  twitter </i> </a> </li>
						<li> <a href="#"> <i class="fa fa-instagram"> instagram  </i> </a> </li>
                        </div>
                    </div>
                </div>
</footer>

</body>
</html>